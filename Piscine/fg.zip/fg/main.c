/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ykaya <ykaya@student.42istanbul.com.tr>    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/07/31 19:35:06 by ykaya             #+#    #+#             */
/*   Updated: 2023/07/31 20:36:50 by ykaya            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
#include <stdlib.h>
#include "include.h"

int	main(int argc, char **argv)
{
	int	i;

	if (argc == 1)
	{
		parse_stdin_print();
		return (0);
	}
	i = 1;
	while (i < argc)
	{
		parse_file_print(argv[i]);
		if (i != argc - 1)
			ft_putchar('\n');
		i++;
	}
	return (0);
}
