/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   utils.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ykaya <ykaya@student.42istanbul.com.tr>    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/07/31 19:35:17 by ykaya             #+#    #+#             */
/*   Updated: 2023/07/31 20:37:01 by ykaya            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
#include <stdlib.h>
#include "include.h"

void	parse_stdin_print(void)
{
	t_parsed_terrain	*pterrain;

	pterrain = malloc(sizeof(t_parsed_terrain));
	if (parse_fildes(STDIN_FILENO, pterrain) < 0)
		write(STDOUT_FILENO, "map error\n", 10);
	else
	{
		solve_and_complete(pterrain->terrain);
		print_terrain(pterrain);
		destroy_terrain(pterrain->terrain);
	}
	free(pterrain);
}

void	parse_file_print(char *filename)
{
	t_parsed_terrain	*pterrain;

	pterrain = malloc(sizeof(t_parsed_terrain));
	if (parse_file(filename, pterrain) < 0)
		write(STDOUT_FILENO, "map error\n", 10);
	else
	{
		solve_and_complete(pterrain->terrain);
		print_terrain(pterrain);
		destroy_terrain(pterrain->terrain);
	}
	free(pterrain);
}

int	count_lines(char *file)
{
	int	counter;

	counter = 0;
	while (*file)
	{
		if (*file == '\n')
			counter++;
		file++;
	}
	return (counter);
}

int	ft_line_len(char *str)
{
	int	counter;

	counter = 0;
	while (str[counter] && str[counter] != '\n')
		counter++;
	return (counter);
}
