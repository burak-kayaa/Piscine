/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   helper.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ykaya <ykaya@student.42istanbul.com.tr>    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/07/31 19:35:00 by ykaya             #+#    #+#             */
/*   Updated: 2023/07/31 20:35:55 by ykaya            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
#include <stdlib.h>
#include "include.h"

char	*read_file(int fildes, int read_size, int buf_size, int file_size)
{
	char	*buf;
	char	*file;

	file = NULL;
	buf = malloc(sizeof(char) * buf_size);
	if (buf == NULL)
		return (NULL);
	while (1)
	{
		read_size = read(fildes, buf, buf_size);
		if (read_size == 0)
			break ;
		if (read_size < 0)
			return (NULL);
		file = ft_memcat(file, buf, file_size, read_size);
		if (file == NULL)
			return (NULL);
		file_size += read_size;
		buf_size *= GROWTH_FACTOR;
		buf = realloc_buf(buf, buf_size);
		if (buf == NULL)
			return (NULL);
	}
	free(buf);
	return (file);
}

char	*ft_memcat(char *file, char *buf, int file_size,
					int read_size)
{
	int		i;
	char	*file_clone;

	file_clone = malloc(sizeof(char) * (file_size + 1));
	if (file_clone == NULL)
		return (NULL);
	i = -1;
	while (++i < file_size)
		file_clone[i] = file[i];
	free(file);
	file = malloc(sizeof(char) * (file_size + read_size + 1));
	if (file == NULL)
		return (NULL);
	i = -1;
	while (++i < file_size)
		file[i] = file_clone[i];
	free(file_clone);
	while (i < file_size + read_size)
	{
		file[i] = buf[i - file_size];
		i++;
	}
	file[i] = '\0';
	return (file);
}

char	*realloc_buf(char *buf, int buf_size)
{
	free(buf);
	buf = (char *)malloc(sizeof(char) * buf_size);
	if (buf == NULL)
		return (NULL);
	return (buf);
}

int	ft_natoi(char *str, unsigned int n)
{
	int				nb;
	unsigned int	i;

	nb = 0;
	i = 0;
	while (str[i] && i < n)
	{
		if (str[i] < '0' || str[i] > '9')
			return (-1);
		i++;
	}
	if (i == 0)
		return (-1);
	i = 0;
	while (str[i] && i < n)
	{
		nb *= 10;
		nb += str[i++] - '0';
	}
	if (nb == 0)
		return (-1);
	return (nb);
}

void	ft_putchar(char c)
{
	write(STDOUT_FILENO, &c, 1);
}
