/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   parse.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ykaya <ykaya@student.42istanbul.com.tr>    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/07/31 19:35:12 by ykaya             #+#    #+#             */
/*   Updated: 2023/07/31 20:52:00 by ykaya            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
#include <stdlib.h>
#include <fcntl.h>
#include "include.h"

int	parse_file(char *filename, t_parsed_terrain *pterrain)
{
	int		fildes;

	fildes = open(filename, O_RDONLY);
	if (fildes < 0)
		return (-1);
	if (parse_fildes(fildes, pterrain) < 0)
	{
		close(fildes);
		return (-1);
	}
	if (close(fildes) < 0)
		return (-1);
	return (0);
}

int	parse_fildes(int fildes, t_parsed_terrain *pterrain)
{
	char	*file;

	file = read_file(fildes, 0, INIT_BUF_SIZE, 0);
	if (file == NULL)
		return (-1);
	if (parse(file, pterrain, -1) < 0)
	{
		free(file);
		return (-1);
	}
	free(file);
	return (0);
}

int	parse(char *file, t_parsed_terrain *pterrain, int y)
{
	int	i;

	pterrain->terrain = (t_terrain *)malloc(sizeof(t_terrain));
	if (pterrain->terrain == NULL)
		return (-1);
	i = parse_header(file, pterrain);
	if (i < 0)
	{
		free(pterrain->terrain);
		return (-1);
	}
	pterrain->terrain->matrix = (int **)malloc(sizeof(int *)
			* pterrain->terrain->rows);
	if (set_dimensions(&file[i], pterrain) < 0
		|| pterrain->terrain->matrix == NULL)
	{
		free(pterrain->terrain);
		return (-1);
	}
	if (parse_2(pterrain, file, y) < 0)
		return (-1);
	return (0);
}

int	parse_2(t_parsed_terrain *pterrain, char *file, int y)
{
	while (++y < pterrain->terrain->rows)
	{
		pterrain->terrain->matrix[y] = set_row(file, pterrain, y);
		if (pterrain->terrain->matrix[y] == NULL)
		{
			destroy_terrain(pterrain->terrain);
			free(pterrain);
			return (-1);
		}
	}
	return (1);
}
