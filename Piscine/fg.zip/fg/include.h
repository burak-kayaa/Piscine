/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   include.h                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ykaya <ykaya@student.42istanbul.com.tr>    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/07/31 20:57:52 by ykaya             #+#    #+#             */
/*   Updated: 2023/07/31 20:57:52 by ykaya            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef INCLUDE_H
# define INCLUDE_H

# define TRUE 1
# define FALSE 0
# define INIT_BUF_SIZE 2
# define GROWTH_FACTOR 2
# define EMPTY 1
# define OBSTACLE 0
# define FILLED -1

typedef struct s_terrain
{
	int	rows;
	int	columns;
	int	**matrix;
}				t_terrain;

typedef struct s_parsed_terrain
{
	char		empty;
	char		obstacle;
	char		filled;
	t_terrain	*terrain;
}				t_parsed_terrain;

typedef struct s_cell
{
	int	y;
	int	x;
	int	value;
}				t_cell;

char			*read_file(int fildes, int read_size, 
					int buf_size, int file_size);
char			*ft_memcat(char *file, char *buf, int file_size,
					int read_size);
char			*realloc_buf(char *buf, int buf_size);
int				ft_natoi(char *str, unsigned int n);
void			ft_putchar(char c);

int				ft_min(int nb1, int nb2, int nb3);
t_cell			solve(t_terrain *terrain, int y);
void			solve_and_complete(t_terrain *terrain);

int				parse_file(char *filename, t_parsed_terrain *pterrain);
int				parse_fildes(int fildes, t_parsed_terrain *pterrain);
int				parse(char *file, t_parsed_terrain *pterrain, int y);
int				parse_2(t_parsed_terrain *pterrain, char *file, int y);

int				*set_row(char *file, t_parsed_terrain *pterrain, int y);
int				set_dimensions(char *file, t_parsed_terrain *pterrain);
int				parse_header(char *file, t_parsed_terrain *pterrain);

void			destroy_terrain(t_terrain *terrain);
void			print_terrain(t_parsed_terrain *parsed_terrain);
int				terrain_to_string(t_parsed_terrain *pterrain, char *str);

void			parse_stdin_print(void);
void			parse_file_print(char *filename);
int				count_lines(char *file);
int				ft_line_len(char *str);

#endif