#include "ft_abs.h"
#include <stdio.h>
int main()
{
	printf("%d",ABS(-3));
}
