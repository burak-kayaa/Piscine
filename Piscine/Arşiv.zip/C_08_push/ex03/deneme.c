#include "ft_point.h"
/*

typedef struct

{
	int yas;
	char *isim;
	char *soyisi::m;

}musteri;*/
#include <stdio.h>
int main()
{
	/*
	char *isim = "burak";
	char *soyisim = "kaya;
	int yas = 19;
	musteri burak;
	burak.yas = 19;
	burak.isim = "burak";
	burak.soyisim = "kaya";*/
	t_point sayı;
	sayı.x= 42;
	sayı.y= 21; 
	printf("%d",sayı.x);
}
