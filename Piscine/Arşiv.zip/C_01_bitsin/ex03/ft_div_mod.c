/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_div_mod.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: burkaya <burkaya@student.42istanbul.com.t  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/07/17 18:15:11 by burkaya           #+#    #+#             */
/*   Updated: 2023/07/17 18:24:22 by burkaya          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
void	ft_div_mod(int a, int b, int *div, int *mod)
{
	int	div_i;
	int	mod_i;

	div_i = a / b;
	mod_i = a % b;
	*div = div_i;
	*mod = mod_i;
}
