/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_rev_int_tab.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: burkaya <burkaya@student.42istanbul.com.t  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/07/18 14:39:59 by burkaya           #+#    #+#             */
/*   Updated: 2023/07/18 15:13:40 by burkaya          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void	ft_rev_int_tab(int *tab, int size)
{
	int	head;
	int	tail;
	int	temp;

	tail = size - 1;
	head = 0;
	while (head < tail)
	{
		temp = tab[head];
		tab[head] = tab[tail];
		tab[tail] = temp;
		tail--;
		head++;
	}
}
