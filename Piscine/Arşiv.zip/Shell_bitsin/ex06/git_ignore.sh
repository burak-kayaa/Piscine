git ls-files -i --exclude-standard --others
