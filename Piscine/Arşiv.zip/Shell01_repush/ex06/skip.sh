ls -l | sed -n "p;n"
