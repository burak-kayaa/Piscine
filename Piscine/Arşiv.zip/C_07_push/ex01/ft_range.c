/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_range.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: burkaya <burkaya@student.42istanbul.com.t  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/07/30 12:31:43 by burkaya           #+#    #+#             */
/*   Updated: 2023/07/31 15:49:52 by burkaya          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <stdlib.h>

int	*ft_range(int min, int max)
{
	int	i;
	int	*d;

	i = 0;
	if (min >= max)
		return (0);
	d = (int *)malloc((max - min) * 4);
	if (d == NULL)
		return (0);
	while (min + i < max)
	{
		d[i] = min + i;
		i++;
	}
	return (d);
}
